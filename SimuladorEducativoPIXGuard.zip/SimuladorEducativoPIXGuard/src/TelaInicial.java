import javax.swing.*;
import java.awt.*;

public class TelaInicial extends JFrame {

    public TelaInicial() {
        setTitle("PIXGuard - Simulador Educativo");
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("PIXGuard", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setOpaque(true);
        lblTitulo.setBackground(new Color(0, 120, 106));
        lblTitulo.setPreferredSize(new Dimension(400, 60));

        JTextArea areaTexto = new JTextArea();
        areaTexto.setText("🚨 Bem-vindo ao Simulador Educativo PIXGuard 🚨\n\n"
            + "Neste simulador, você aprenderá como identificar e evitar golpes comuns no Pix.\n"
            + "⚠️ Nunca envie dinheiro para contatos desconhecidos.\n"
            + "⚠️ Desconfie de mensagens urgentes cobrando pagamentos.\n"
            + "⚠️ Verifique sempre o nome e CPF do destinatário.\n\n"
            + "Clique em 'Iniciar Simulação' para testar seu conhecimento!");
        areaTexto.setEditable(false);
        areaTexto.setFont(new Font("SansSerif", Font.PLAIN, 14));
        areaTexto.setLineWrap(true);
        areaTexto.setWrapStyleWord(true);
        areaTexto.setMargin(new Insets(10, 10, 10, 10));

        JButton btnIniciar = new JButton("Iniciar Simulação");
        btnIniciar.setFont(new Font("SansSerif", Font.BOLD, 18));
        btnIniciar.setBackground(new Color(0, 120, 106));
        btnIniciar.setForeground(Color.WHITE);
        btnIniciar.setFocusPainted(false);

        btnIniciar.addActionListener(e -> {
            new TelaPix(this).setVisible(true);
            this.setVisible(false);
        });

        add(lblTitulo, BorderLayout.NORTH);
        add(new JScrollPane(areaTexto), BorderLayout.CENTER);
        add(btnIniciar, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaInicial().setVisible(true));
    }
}