import javax.swing.*;
import java.awt.*;

public class TelaPIXGuard extends JFrame {

    public TelaPIXGuard(JFrame telaAnterior, String chave) {
        setTitle("PIXGuard - Assistente Inteligente");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel lblAviso = new JLabel("<html><center>🧠 PIXGuard: Análise de Segurança<br><br>"
            + "A chave informada (" + chave + ") pertence a um usuário com SCORE BAIXO.<br>"
            + "Essa transação pode ser um GOLPE.<br><br>"
            + "Você deseja continuar?</center></html>", SwingConstants.CENTER);
        lblAviso.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JButton btnRealizar = new JButton("Realizar o Pix");
        JButton btnCancelar = new JButton("Cancelar Operação");

        btnRealizar.setBackground(new Color(0, 120, 106));
        btnRealizar.setForeground(Color.WHITE);

        btnCancelar.setBackground(Color.GRAY);
        btnCancelar.setForeground(Color.WHITE);

        btnRealizar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "❌ Pix realizado para um contato suspeito.\n⚠️ Golpe simulado! Sempre verifique a autenticidade antes de transferir.");
            System.exit(0);
        });

        btnCancelar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "✅ Parabéns! Você evitou um golpe.\nSempre desconfie de mensagens urgentes.");
            System.exit(0);
        });

        JPanel painelBotoes = new JPanel();
        painelBotoes.add(btnRealizar);
        painelBotoes.add(btnCancelar);

        add(lblAviso, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);
    }
}