import javax.swing.*;
import java.awt.*;

public class TelaPix extends JFrame {

    public TelaPix(JFrame telaAnterior) {
        setTitle("Simulação de PIX");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel lblInstrucao = new JLabel("<html><center>Você recebeu uma mensagem urgente<br>"
            + "dizendo que precisa transferir R$100 via Pix.<br>"
            + "Informe a chave Pix para continuar:</center></html>", SwingConstants.CENTER);
        lblInstrucao.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JTextField txtChave = new JTextField();
        txtChave.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JButton btnContinuar = new JButton("Continuar");
        btnContinuar.setBackground(new Color(0, 120, 106));
        btnContinuar.setForeground(Color.WHITE);

        btnContinuar.addActionListener(e -> {
            String chave = txtChave.getText().trim();
            if (!chave.isEmpty()) {
                new TelaPIXGuard(this, chave).setVisible(true);
                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Digite uma chave Pix para continuar.");
            }
        });

        JPanel painelCentro = new JPanel(new GridLayout(3, 1, 10, 10));
        painelCentro.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        painelCentro.add(lblInstrucao);
        painelCentro.add(txtChave);
        painelCentro.add(btnContinuar);

        add(painelCentro, BorderLayout.CENTER);
    }
}