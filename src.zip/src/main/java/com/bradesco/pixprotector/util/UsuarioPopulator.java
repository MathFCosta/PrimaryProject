package com.bradesco.pixprotector.util;

import com.bradesco.pixprotector.model.Usuario;
import com.bradesco.pixprotector.repository.UsuarioRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Random;
import java.util.UUID;
import java.math.BigDecimal;

@Component
public class UsuarioPopulator {

    @Autowired
    private UsuarioRepository usuarioRepository;

    private final String[] nomes = {
        "Carlos", "Fernanda", "João", "Mariana", "Ricardo",
        "Luciana", "Eduardo", "Patrícia", "Paulo", "Aline"
    };

    private final String[] sobrenomes = {
        "Silva", "Oliveira", "Souza", "Lima", "Costa",
        "Almeida", "Ferreira", "Ribeiro", "Martins", "Gomes"
    };

    private final Random random = new Random();

    @PostConstruct
    public void popularUsuarios() {
        // Evita duplicação ao reiniciar o sistema
        if (usuarioRepository.count() > 0) return;

        for (int i = 0; i < 100; i++) {
            Usuario u = new Usuario();

            String nomeCompleto = gerarNomeCompleto();
            String cpf = gerarCpf();
            String telefone = gerarTelefone();
            String email = gerarEmail(nomeCompleto);
            String chaveAleatoria = UUID.randomUUID().toString();
            LocalDate dataNascimento = gerarDataNascimento();
            int score = random.nextInt(1001); // score de 0 a 1000
            BigDecimal saldo = BigDecimal.valueOf(100 + (20000 * random.nextDouble()))
                             .setScale(2, BigDecimal.ROUND_HALF_EVEN); // saldo entre R$100 e R$20.100

            u.setNome(nomeCompleto);
            u.setCpf(cpf);
            u.setTelefone(telefone);
            u.setEmail(email);
            u.setChaveAleatoria(chaveAleatoria);
            u.setDataNascimento(dataNascimento);
            u.setScore(score);
            u.setSaldo(saldo);

            usuarioRepository.save(u);
        }
    }

    private String gerarNomeCompleto() {
        return nomes[random.nextInt(nomes.length)] + " " +
               sobrenomes[random.nextInt(sobrenomes.length)];
    }

    private String gerarCpf() {
        return String.format("%03d.%03d.%03d-%02d",
                random.nextInt(1000),
                random.nextInt(1000),
                random.nextInt(1000),
                random.nextInt(100));
    }

    private String gerarTelefone() {
        return String.format("(%02d)%05d-%04d",
                random.nextInt(90) + 10,
                random.nextInt(90000),
                random.nextInt(10000));
    }

    private String gerarEmail(String nome) {
        String base = nome.toLowerCase().replace(" ", ".");
        return base + "@email.com";
    }

    private LocalDate gerarDataNascimento() {
        int ano = random.nextInt(2003 - 1960) + 1960;
        int mes = random.nextInt(12) + 1;
        int dia = random.nextInt(28) + 1; // para evitar problemas de dias inválidos
        return LocalDate.of(ano, mes, dia);
    }
}