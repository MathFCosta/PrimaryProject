package com.bradesco.pixprotector.repository;

import com.bradesco.pixprotector.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByCpfOrTelefoneOrEmailOrChaveAleatoria(
        String cpf, String telefone, String email, String chaveAleatoria
    );
}