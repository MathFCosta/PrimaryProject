package com.bradesco.pixprotector.api;

import com.bradesco.pixprotector.model.Transacao;
import com.bradesco.pixprotector.service.TransacaoService;
import com.bradesco.pixprotector.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transacoes")
public class TransacaoController {

    @Autowired
    private TransacaoService transacaoService;

    @Autowired
    private ScoreService scoreService;

    // 1. Registrar nova transação
    @PostMapping
    public ResponseEntity<?> registrarTransacao(@RequestBody Transacao transacao) {
        // Verifica o score real do destinatário no banco
        int score = scoreService.calcularScore(transacao.getChaveDestino());

        if (score < 300) {
            return ResponseEntity
                    .status(403)
                    .body("Transação recusada por baixa confiabilidade. Score: " + score);
        }

        Transacao salva = transacaoService.salvarTransacao(transacao);
        return ResponseEntity.ok(salva);
    }

    // 2. Consultar reputação de um destinatário
    @GetMapping("/score/{cpfCnpj}")
    public ResponseEntity<?> consultarScore(@PathVariable String cpfCnpj) {
        int score = scoreService.calcularScore(cpfCnpj);
        return ResponseEntity.ok(score);
    }

    // 3. Verificar se há alerta para o destinatário
    @GetMapping("/alerta/{cpfCnpj}")
    public ResponseEntity<?> verificarAlerta(@PathVariable String cpfCnpj) {
        boolean alerta = scoreService.deveExibirAlerta(cpfCnpj);
        return ResponseEntity.ok(alerta);
    }
}