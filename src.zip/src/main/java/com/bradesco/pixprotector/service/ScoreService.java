package com.bradesco.pixprotector.service;

import com.bradesco.pixprotector.model.Usuario;
import com.bradesco.pixprotector.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ScoreService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Calcula um score dinâmico com base em heurísticas de valor e domínio.
    public int calcularScore(String chaveOrigem, String chaveDestino, double valor) {
        int score = 1000;

        // Penaliza transações de valor muito baixo
        if (valor < 10) {
            score -= 300;
        }

        // Penaliza transações de valor muito alto
        if (valor > 10000) {
            score -= 400;
        }

        // Penaliza se for e-mail com domínios diferentes
        if (chaveOrigem.contains("@") && chaveDestino.contains("@")) {
            String dominioOrigem = chaveOrigem.substring(chaveOrigem.indexOf("@") + 1);
            String dominioDestino = chaveDestino.substring(chaveDestino.indexOf("@") + 1);
            if (!dominioOrigem.equalsIgnoreCase(dominioDestino)) {
                score -= 200;
            }
        }

        // Garante score entre 0 e 1000
        return Math.max(0, Math.min(1000, score));
    }
    
     //Calcula o score real de um usuário a partir de qualquer chave Pix.
    
    public int calcularScore(String chavePix) {
        Optional<Usuario> opt = usuarioRepository.findByCpfOrTelefoneOrEmailOrChaveAleatoria(
                chavePix, chavePix, chavePix, chavePix
        );

        return opt.map(Usuario::getScore).orElse(0); // 0 se não encontrar
    }

    public boolean deveExibirAlerta(String chavePix) {
        return calcularScore(chavePix) < 300;
    }
}