package com.bradesco.pixprotector.service;

import com.bradesco.pixprotector.model.Transacao;
import com.bradesco.pixprotector.model.Usuario;
import com.bradesco.pixprotector.repository.TransacaoRepository;
import com.bradesco.pixprotector.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TransacaoService {

    private final TransacaoRepository transacaoRepository;
    private final UsuarioRepository usuarioRepository;

    @Autowired
    public TransacaoService(TransacaoRepository transacaoRepository, UsuarioRepository usuarioRepository) {
        this.transacaoRepository = transacaoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public Transacao salvarTransacao(Transacao transacao) {
        // Buscar o usuário que está enviando (chave de origem)
        Optional<Usuario> usuarioOpt = usuarioRepository
            .findByCpfOrTelefoneOrEmailOrChaveAleatoria(
                transacao.getChaveOrigem(),
                transacao.getChaveOrigem(),
                transacao.getChaveOrigem(),
                transacao.getChaveOrigem()
            );

        usuarioOpt.ifPresent(transacao::setUsuario);

        transacao.setDataHora(LocalDateTime.now());

        return transacaoRepository.save(transacao);
    }

    public List<Transacao> listarTransacoes() {
        return transacaoRepository.findAll();
    }
}